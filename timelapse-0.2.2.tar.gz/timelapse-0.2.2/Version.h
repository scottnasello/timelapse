//
//  Version.h
//  TimeLapse
//
//  Created by Jim Studt on 1/10/14.
//  Copyright (c) 2014 Lunarware. All rights reserved.
//

#ifndef TimeLapse_Version_h
#define TimeLapse_Version_h

#define TIMELAPSE_VERSION "0.2.2"

#endif
